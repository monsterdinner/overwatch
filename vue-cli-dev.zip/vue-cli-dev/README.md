# vue-cli [![Build Status](https://circleci.com/gh/vuejs/vue-cli/tree/dev.svg?style=shield)](https://circleci.com/gh/vuejs/vue-cli/tree/dev) [![Windows Build status](https://ci.appveyor.com/api/projects/status/rkpafdpdwie9lqx0/branch/dev?svg=true)](https://ci.appveyor.com/project/yyx990803/vue-cli/branch/dev)

> Vue CLI is the Standard Tooling for Vue.js Development.

## Documentation

Docs are available at https://cli.vuejs.org/ - we are still working on refining it and contributions are welcome!

## Contributing

Please see [contributing guide](https://github.com/vuejs/vue-cli/blob/dev/.github/CONTRIBUTING.md).

## License

[MIT](https://github.com/vuejs/vue-cli/blob/dev/LICENSE)
