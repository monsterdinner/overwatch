<template>
  <p class="bit-sponsor">
    <a href="https://www.bitsrc.io/?utm_source=vue&utm_medium=vue&utm_campaign=vue&utm_term=vue&utm_content=vue" target="_blank">
      <span>This project is sponsored by</span>
      <img alt="bit" src="https://raw.githubusercontent.com/vuejs/vuejs.org/master/themes/vue/source/images/bit-wide.png">
    </a>
  </p>
</template>

<style lang="stylus">
.bit-sponsor
  font-weight 600
  background-color #f3f6f8
  padding 0.6em 1.2em
  border-radius 8px
  display inline-block
  margin 1em 0 !important
  a
    color #999
  img
    height 40px
    margin-left 15px
  img, span
    vertical-align middle
</style>
